import pandas as pd

xls = pd.read_excel(r'C:\Users\20120\Desktop\食品营养成分表.xls')
print(xls)
print(type(xls))